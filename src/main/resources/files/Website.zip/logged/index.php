<?php
include '../config.php';
session_start();
?>
<?php

		if($pagestyle == 2) {
			if(isset($_GET["set"])) {
				if($_GET["set"] == "server") {
				include "tech/page/style2/server.php";
				}
				if($_GET["set"] == "proxy") {
				include "tech/page/style2/proxy.php";
				}
			} else {
				include "tech/page/style2/index.php";
				}


		} else {
		include "tech/page/style1/index.php";
		}
	?>
